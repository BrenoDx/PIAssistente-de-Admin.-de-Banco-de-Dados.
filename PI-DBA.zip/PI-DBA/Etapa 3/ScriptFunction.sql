----- Function para descontos 
DELIMITER //
CREATE FUNCTION desconto_venda(venda_id INT)
RETURNS DECIMAL(9,2)
READS SQL DATA
BEGIN
	DECLARE valorDesconto DECIMAL(9,2);
	SELECT valorTotal INTO valorDesconto FROM venda 
	WHERE id = venda_id;

IF valorDesconto > 600.00 THEN
	RETURN valorDesconto - (valorDesconto * 0.15);
ELSE
	RETURN valorDesconto - (valorDesconto* 0.05);
END IF;
END //
DELIMITER ;

SELECT desconto_venda(3)
----- Function para desconto
----- Clientes que comprarem acima de 600 reais terá 15% de desconto senão apenas 5% que é no caso da venda id 3