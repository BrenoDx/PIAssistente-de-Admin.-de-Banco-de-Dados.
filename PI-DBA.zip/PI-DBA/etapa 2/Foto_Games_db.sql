CREATE DATABASE fg_db;

USE fg_db;

----- TABELA DE ESTOQUE
 CREATE TABLE estoque
 (
 id INT NOT NULL AUTO_INCREMENT,
 nomeProduto VARCHAR(120) NOT NULL,
 quantidade INT NOT NULL,
 PRIMARY KEY(id)
 );
ALTER TABLE estoque MODIFY nomeProduto VARCHAR(300)
 
 ----- TABELA DO PRODUTO
 CREATE TABLE produto
 (
 id INT NOT NULL AUTO_INCREMENT,
 fabricante VARCHAR(45) NOT NULL,
 categoria VARCHAR(45) NOT NULL,
 descricao LONGTEXT NOT NULL,
 valor DECIMAL(9,2) NOT NULL,
 estoque_id INT NOT NULL,
 PRIMARY KEY(id),
	FOREIGN KEY (estoque_id) 
		REFERENCES estoque (id) 
 );
 
 ----- TABELA DE FUNCIONÁRIOS
 CREATE TABLE funcionario
 (
 id INT NOT NULL AUTO_INCREMENT,
 nome VARCHAR(45) NOT NULL,
 cargo VARCHAR(45) NOT NULL,
 cpf VARCHAR(11) NOT NULL,
 telefone VARCHAR(11) NOT NULL,
 matricula VARCHAR(5) NOT NULL,
 email VARCHAR(45) NOT NULL,
 PRIMARY KEY(id)
 );
 
 ----- TABELA DE CLIENTE
 CREATE TABLE cliente
 (
 id INT NOT NULL AUTO_INCREMENT,
 nome VARCHAR(45) NOT NULL,
 cpf VARCHAR(11) NOT NULL,
 telefone VARCHAR(11) NOT NULL,
 email VARCHAR(45) NOT NULL,
 nascimento DATE,
 PRIMARY KEY(id)
 );
 
 ----- TABELA DE ORÇAMENTOS
 CREATE TABLE orcamento
 (
 id INT NOT NULL AUTO_INCREMENT,
 data DATE NOT NULL,
 cliente_id INT NOT NULL,
 funcionario_id INT NOT NULL,
 PRIMARY KEY(id),
	FOREIGN KEY (cliente_id)
		REFERENCES cliente (id),
			FOREIGN KEY (funcionario_id)
				REFERENCES funcionario (id)
 );
 
 ----- TABELA LIGAÇÃO ORÇAMENTOS E PRODUTOS
 CREATE TABLE orcamento_produto
 (
 qntdProduto INT NOT NULL,
 valorTotal DECIMAL(9,2) NOT NULL,
 orcamento_id INT NOT NULL,
 produto_id INT NOT NULL,
 FOREIGN KEY (orcamento_id)
	REFERENCES orcamento (id),
		FOREIGN KEY (produto_id)
			REFERENCES produto (id)
 );
 
 ----- TABELA DE VENDAS
 CREATE TABLE venda
 (
 id INT NOT NULL AUTO_INCREMENT,
 data DATE NOT NULL,
 valorTotal DECIMAL(9,2) NOT NULL,
 formPagamento VARCHAR(20) NOT NULL,
 nf INT NOT NULL,
 orcamento_id INT,
 funcionario_id INT NOT NULL,
 cliente_id INT NOT NULL,
 PRIMARY KEY(id),
	FOREIGN KEY (orcamento_id)
		REFERENCES orcamento (id),
			FOREIGN KEY (funcionario_id)
				REFERENCES funcionario (id),
			FOREIGN KEY (cliente_id)
		REFERENCES cliente (id)
 );
 
 ----- TABELA LIGAÇÃO VENDA E PRODUTO
 CREATE TABLE venda_produto
 (
 qntdProduto INT NOT NULL,
 venda_id INT NOT NULL,
 produto_id INT NOT NULL,
 FOREIGN KEY (venda_id)
	REFERENCES venda (id),
		FOREIGN KEY (produto_id)
			REFERENCES produto (id)
 );
 
