
INSERT INTO estoque(nomeProduto, quantidade) VALUES
("RX 6600 V2 ASUS Dual AMD Radeon, 8gb GDDR6", 7), ("RTX 4060 TI Ventus 2X Black 8G OC MSI NVIDIA GeForce, 8GB GDDR6", 8),
("Memória RAM Kingston Fury Beast, 8GB, 3200MHz, DDR4, CL16, Preto", 15), ("Memória RAM Kingston Fury Beast, 16GB, 3200MHz, DDR4, CL16, Preto", 15),
("Gigabyte H510M H V2, Intel LGA 1200, 10ª E 11ª Geração, mATX, DDR4", 10), ("Asus Prime B760M-A Wi-Fi, Intel LGA 1700, mATX, D4,DDR4, Wi-Fi", 5),
("ASRock B450M Steel Legend, AMD AM4, mATX, DDR4", 10), ("Intel Core i5-10400F, 2.9GHz (4.3GHz Max Turbo), Cache 12MB, 6 Núcleos, 12 Threads, LGA 1200", 10),
("AMD Ryzen 5 5600, 3.5GHz (4.4GHz Max Turbo), Cache 35MB, AM4, Sem Vídeo", 7), ("Playstation 5 Sony, SSD 825GB, Controle sem fio DualSense, Com Mídia Física", 10),
("Console PlayStation 5 Slim, Edição Digital, Branco + 2 Jogos Design Slim", 5), ("Headset sem fio Gamer Sony Pulse Elite, Bluetooth, PS5, Branco", 10),
("Headset Gamer Sem Fio Redragon Zeus Pro, 7.1, Driver 53mm, Bluetooth, Preto", 15), ("Headset Gamer Sem Fio Astro A50 + Base Station Gen 4 com Áudio Dolby para PS4, PC, Mac - Preto",7),
("Marvels Spider-Man 2 Standard Edition, Playstation 5 - Mídia Física", 20), ("Stellar Blade, PS5", 5), ("EA Sports FC 24 Standard Edition, Playstation 5 - Mídia Física", 20),
("Elden Ring Shadow Of The Erdtree, PS5 - Mídia Física", 7), ("Death Stranding: Versão do Diretor, PS5", 7);

INSERT INTO produto(fabricante, categoria, descricao, valor, estoque_id) VALUES
("ASUS", "PLACA DE VÍDEO", "Placa de vídeo oferecendo a mais recente experiência de arquitetura AMD RDNA 2 na sua forma mais pura, o ASUS Dual Radeon RX 6600 V2 combina desempenho e simplicidade como nenhum outro.
 Aproveitando tecnologias de refrigeração avançadas derivadas de placas gráficas emblemáticas, a escolha perfeita para uma construção bem equilibrada. Aperte os cintos e envolva-se em proezas de jogo de ponta.", 1299.99, 1),
("MSI", "PLACA DE VÍDEO", "O VENTUS traz uma experiência fundamentalmente sólida para usuários que procuram uma placa gráfica de alto desempenho. Um design atualizado de aparência nítida com o TORX FAN 4.0 permite que o
 VENTUS passe por qualquer tarefa.", 2319.99, 2),
 ("KINGSTON", "MEMÓRIA RAM", "Memória Kingston Fury Beast A memória Kingston FURY Beast DDR4 proporciona um poderoso aumento de performance para jogos, edição de vídeo e renderização. Ela faz o overclock automático para a 
 especificação de maior performance do módulo que seja suportada pelo sistema* e está pronta para Intel XMP e AMD Ryzen. Com o seu dissipador de calor de perfil baixo, a memória FURY Beast DDR4 permanece fria e pronta para o 
 seu game. 100% testada na fábrica, é a atualização definitiva para seu computador. Os processadores/chipsets da Intel até a 7ª Geração não eram desenvolvidos para suportar módulos de memória DDR4 fabricados com chips DRAM de densidade 16Gbit.", 189.99, 3),
("KINGSTON", "MEMÓRIA RAM", "A memória Kingston FURY Beast DDR4 proporciona um poderoso aumento de performance para jogos, edição de vídeo e renderização. Ela faz o overclock automático para a especificação de maior performance do módulo que seja suportada
 pelo sistema* e está pronta para Intel XMP e AMD Ryzen. Com o seu dissipador de calor de perfil baixo, a memória FURY Beast DDR4 permanece fria e pronta para o seu game. 100% testada na fábrica, é a atualização definitiva para seu computador. 
 Os processadores/chipsets da Intel até a 7ª Geração não eram desenvolvidos para suportar módulos de memória DDR4 fabricados com chips DRAM de densidade 16Gbit.", 299.99, 4),
("GIGABYTE", "PLACA MÃE", "As placas-mãe GIGABYTE estão focadas em fornecer tecnologia M.2 para entusiastas que desejam maximizar o potencial de seus sistemas.", 449.99, 5),
("ASUS", "PLACA MÃE", "Com um design de energia robusto, soluções de resfriamento abrangentes e opções de ajuste inteligentes, o PRIME B760M-A WIFI D4 oferece aos usuários e construtores de PC DIY uma variedade de otimizações de desempenho por meio de 
software intuitivo e recursos de firmware.", 1159.99, 6),
("AS ROCK", "PLACA MÃE", "Placa-mãe ASRock B450M Steel Legend AMD DDR4 Resistente como aço, verdadeira lenda a Steel Legend representa o estado filosófico da sólida durabilidade e irresistível estética. Construída ao redor das especificações e recursos 
mais exigentes, a série Steel Legend visa os usuários do dia a dia e entusiastas mainstream!Oferecendo uma forte gama de materiais/componentes para assegurar um desempenho estável e confiável.", 712.49, 7),
("INTEL", "PROCESSADOR", "Processador Intel Core i5-10400F Os novos processadores Intel Core da 10ª Geração oferecem atualizações de desempenho incríveis para melhorar a produtividade e proporcionar entretenimento surpreendente, incluindo até 5,3 GHz, 
Intel® Wi-Fi 6 (Gig) tecnologia Thunderbolt™ 3, HDR 4K, otimização de sistema inteligentes e muito mais. Produtividade acelerada Recursos de desempenho inteligente integrados aprendem e se adaptam ao que você faz, direcionando potência dinamicamente 
para onde ela é mais necessária. Os processadores Intel® Core™ da 10ª Geração com memória Intel® Optane™ fornecem a responsividade para fazer mais.", 579.99, 8),
("AMD", "PROCESSADOR", "Quando você tem a arquitetura de processador de desktop mais avançada do mundo2 para jogadores e criadores de conteúdo, as possibilidades são infinitas. Esteja você jogando os jogos mais recentes, projetando o próximo prédio 
ou processando dados, você precisa de um processador poderoso que possa lidar com tudo - e muito mais. Sem dúvida, os processadores AMD Ryzen ™ série 5000 definem o padrão para jogadores e artistas.", 848.99, 9),
("SONY", "VIDEO GAME", "Jogar no PS5 não tem limites, desfrute do carregamento do seu PS5, extremamente rápido com o SSD de altíssima velocidade, uma imersão mais profunda com suporte a feedback tátil, gatilhos adaptáveis e áudio 3D, além de uma geração 
inédita de jogos incríveis para PlayStation. Veloz como um raio, SSD ultrarrápido Domine o poder de uma CPU e GPU personalizadas e o SSD com E/S integradas que redefinem as regras do que o console PlayStation pode fazer.", 3719.91, 10),
("SONY", "VIDEO GAME", "Com o PS5 Slim, os jogadores contam com uma poderosa tecnologia de jogos em um design elegante e compacto. 1TB de armazenamento tenha seus jogos favoritos prontos e esperando para você começar a jogar com 1TB de armazenamento SSD 
integrado. Inclui os jogos de sucesso Returnal e Ratchet & Clank: Em Uma Outra Dimensão Quebre o ciclo com o jogo de tiro ao estilo rougue Returnal, além de decolar para uma aventura interdimensional, que é sucesso para todas as idades, 
Ratchet & Clank: Em Uma Outra Dimensão. Ambos exploram os principais recursos do PS5.", 3533.91, 11),
("SONY", "HEADSET", "Descubra uma nova era de áudio para games com os alto-falantes planares magnéticos inspirados em estúdio e que reproduzem a sonoridade ambiente com distorção ultrabaixa para fornecer grande riqueza de detalhes, para que você ouça 
exatamente o que os desenvolvedores de jogos pretendiam. Sinta a ação com graves profundos e nítidos e eleve sua percepção com posicionamento mais preciso de sinais de áudio em jogos PS5 compatíveis com áudio 3D.", 929.21, 12),
("REDRAGON", "HEADSET", "O headset gamer Redragon Zeus Pro é a escolha perfeita para quem busca um produto de qualidade, com excelente desempenho e conforto. Com um design moderno e ergonômico, ele proporciona horas de diversão sem cansaço.", 329.90, 13),
("ASTRO", "HEADSET", "Experimente o lendário desempenho dos headsets A50 em sua nova geração, com a conveniência e a liberdade sem fios, atualizado com a qualidade de som totalmente imersiva do ASTRO Audio V2.", 1499.99, 14),
("INSOMNIAC", "JOGO", "o próximo jogo da franquia marvels spider-man, chegando para o console playstation 5", 269.90, 15),
("SHIFT UP", "JOGO", "O futuro da humanidade está no fio de uma lâmina. A Terra foi devastada por criaturas estranhas poderosas e os sobreviventes da raça humana fugiram para uma colônia no espaço sideral. Após viajar da Colônia, EVE chega nos restos 
desolados de nosso planeta com uma missão bem clara: salvar a humanidade e recuperar a Terra dos naytiba, a força malévola que a devastou. Mas enquanto EVE confronta os naytiba um por um, juntando os mistérios do passo nas ruínas da civilização humana, 
ela percebe que sua missão passa longe de ser simples. Na verdade, quase nada é o que parece…", 263.91, 16),
("ELETRONIC ARTS", "JOGO", "O ea sports fc™ 24 é uma nova era para o jogo de todo mundo: mais de 19.000 atletas com licença completa, mais de 700 times e mais de 30 ligas, tudo isso na experiência de futebol", 296.10, 17),
("BANDAI NAMCO", "JOGO", "Guiados pelo Empirio Miquella, os jogadores são levados para a Terra das Sombras, um lugar obscurecido pela Térvore, onde a deusa Marika pisou pela primeira vez. Nessas novas terras desconhecidas, jogadores descobrirão segredos 
obscuros do mundo, conhecendo outros que seguem os passos de Miquella com intenções ocultas.", 399.89, 18),
("KOJIMA PRODUCTIONS", "JOGO", "Da mente do desenvolvedor de jogos lendário Hideo Kojima, nasce uma experiência que redefine um gênero, agora expandida e remasterizada neste Director's Cut definitivo.", 219.91, 19);

INSERT INTO funcionario(nome, cargo, cpf, telefone, matricula, email) VALUES 
("Breno Alves de Araújo", "gerente","23184777704", "11976420630", "64815", "brenoalves@fg.com.br"),
("Alisson Freire Junior", "atendente", "65745826108", "11947268120", "2657", "alissonjunior@fg.com.br"),
("Larissa Gomez da Silva", "atendente", "75486523907", "11986357458", "3645", "larissagomez@fg.com.br"),
("Julia Alves Gomez", "atendente", "65859464812", "11976654359", "6435", "juliaalves@fg.com.br");

INSERT INTO cliente(nome, cpf, telefone, email, nascimento) VALUES
("Lucas Silva", "23526549815", "11989647251", "lucassilva@bmail.com", "1985-02-23"),
("Gabriel Lucca Alves", "98761935412", "11957648239", "gabrielalves@bmail.com", "1999-11-22"),
("Eloisa Ribeiro Silva", "13456148877", "11978864309", "eloisa754@bmail.com", "1982-05-10"),
("Agata Carvalho Gomes", "75645355563", "11989956107", "agata1320@bmail.com", "1987-01-03"),
("Lorenzo Medeiros Richard", "65745688801", "11996437059", "lorenzo_fsd@bmail.com", "1975-05-24");

INSERT INTO orcamento(data, cliente_id, funcionario_id) VALUES
("2024-01-26", 1, 3), ("2024-01-26", 01, 03);

INSERT INTO orcamento_produto(qntdProduto, valorTotal, orcamento_id, produto_id) VALUES
(4, 759.96, 1, 3), (4, 1199.96, 2, 4);

INSERT INTO venda(data, valorTotal, formPagamento, nf, orcamento_id, funcionario_id, cliente_id) VALUES
("2024-01-27", 759.96, "Débito", 2564, 1, 3, 1),
("2024-01-27", 1299.99, "Crédito", 2565, NULL, 2, 4),
("2024-01-27", 579.99, "Crédito", 2566, NULL, 3, 2),
("2024-01-28", 3719.91, "Crédito", 2567, NULL, 4, 3),
("2024-01-28", 929.91, "Débito", 2568, NULL, 2, 5),
("2024-01-28", 659.8, "Débito", 2569, NULL, 3, 1);

INSERT INTO venda_produto(qntdProduto, venda_id, produto_id) VALUES
(4, 1, 3), (1, 2, 1), (1, 3, 8),
(1, 4, 10), (1, 5, 12), (2, 6, 13);

